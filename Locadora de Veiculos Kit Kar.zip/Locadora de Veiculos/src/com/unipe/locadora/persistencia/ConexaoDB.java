
package com.unipe.locadora.persistencia;

/**
 *
 * @author Brauner
 */
public class ConexaoDB {
    
}
